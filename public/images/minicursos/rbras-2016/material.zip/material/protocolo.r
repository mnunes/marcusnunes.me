# baixar os arquivos sra 
# http://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE18508

sri  <- read.csv("SraRunInfo.csv", stringsAsFactors=FALSE)
keep <- grep("CG8144|Untreated-",sri$LibraryName)
sri  <- sri[keep, ]

fs <- basename(sri$download_path)
for(i in 1:nrow(sri)){
	download.file(sri$download_path[i], fs[i])
}

# converter os arquivos .sra para fastq

stopifnot(all(file.exists(fs)))  # verifique se os arquivos foram baixados
for(f in fs) {
	cmd <- paste("fastq-dump --split-3", f)
	cat(cmd,"\n")
	system(cmd)
}

# baixar o genoma de referencia

system("wget ftp://ftp.ensembl.org/pub/release-70/fasta/drosophila_melanogaster/dna/Drosophila_melanogaster.BDGP5.70.dna.toplevel.fa.gz")
system("gunzip Drosophila_melanogaster.BDGP5.70.dna.toplevel.fa.gz")

# baixar as anotacoes dos genes

system("wget ftp://ftp.ensembl.org/pub/release-70/gtf/drosophila_melanogaster/Drosophila_melanogaster.BDGP5.70.gtf.gz")
system("gunzip Drosophila_melanogaster.BDGP5.70.gtf.gz")

# construir o indice de referencia

system("bowtie2-build -f Drosophila_melanogaster.BDGP5.70.dna.toplevel.fa Dme_BDGP5_70")

# verificar a qualidade do sequenciamento

library("ShortRead")
fqQC <- qa(dirPath=".", pattern=".fastq$", type="fastq")
report(fqQC, type="html", dest="fastqQAreport")

# colocar a tabela inicial num formato com uma linha por amostra

sri$LibraryName <- gsub("S2_DRSC_", "", sri$LibraryName) # tirar o label
samples         <- unique(sri[, c("LibraryName", "LibraryLayout")])
for(i in seq_len(nrow(samples))) {
	rw <- (sri$LibraryName==samples$LibraryName[i])
	if(samples$LibraryLayout[i]=="PAIRED") {
		samples$fastq1[i] <- paste0(sri$Run[rw],"_1.fastq",collapse=",")
		samples$fastq2[i] <- paste0(sri$Run[rw],"_2.fastq",collapse=",")
	} else {
		samples$fastq1[i] <- paste0(sri$Run[rw],".fastq",collapse=",")
		samples$fastq2[i] <- ""
	}
}

# adicionar descricoes a tabela de metadados

samples$condition <- "CTL"
samples$condition[grep("RNAi",samples$LibraryName)] = "KD"
samples$shortname <- paste(substr(samples$condition,1,2), substr(samples$LibraryLayout,1,2), seq_len(nrow(samples)), sep=".")

# verificar se esta tudo correto

samples

# alinhar as amostras com o genoma de referencia

gf     <- "Drosophila_melanogaster.BDGP5.70.gtf"
bowind <- "Dme_BDGP5_70"
cmd    <- with(samples,
	paste("tophat -G", gf, "-p 5 -o", LibraryName, bowind, fastq1, fastq2))
system(cmd)

# criar os arquivos BAM

for(i in seq_len(nrow(samples))) {
	lib <- samples$LibraryName[i]
	ob  <- file.path(lib, "accepted_hits.bam")
	
	# classificar por nome, converter para SAM para htseq-count
	cat(paste0("samtools sort -n ",ob," ",lib,"_sn"),"\n")
	cat(paste0("samtools view -o ",lib,"_sn.sam ",lib,"_sn.bam"),"\n")
	
	# classificar por posicao e indice para IGV
	cat(paste0("samtools sort ",ob," ",lib,"_s"),"\n")
	cat(paste0("samtools index ",lib,"_s.bam"),"\n\n")
}


# inspecionar os alinhamentos utilizando o IGV

# contar as leituras utilizando o htseq-count

samples$countf <- paste(samples$LibraryName, "count", sep=".")
gf             <- "Drosophila_melanogaster.BDGP5.70.gtf"
cmd            <- paste0("htseq-count -s no -a 10 ", samples$LibraryName, "_sn.sam ", gf," > ", samples$countf)
cmd



################################
### analise utilizando edgeR ###
################################

# carregar o pacote edgeR e criar um CountDataSet

library("edgeR")

counts  <- read.csv(file="counts.csv", header=T) # opcao 1
d       <- DGEList(counts=dados, group=samples$condition) # opcao 1

counts <- readDGE(samples$countf)$counts # opcao 2

# filtrar os genes pouco expressados e nao-informativos

noint  <- rownames(counts) %in% c("no_feature", "ambiguous", "too_low_aQual", "not_aligned", "alignment_not_unique")
cpms   <- cpm(counts)
keep   <- rowSums(cpms>1)>=3 & !noint
counts <- counts[keep, ]

# visualizar e inspecionar a tabela de contagens

colnames(counts) <- samples$shortname
head(counts[, order(samples$condition)])

# verificar as estatisticas das contagens

summary(counts)

# construir os histogramas

hist(counts[, 1], main="CT.PA.1", xlim=c(0, 5000), breaks=1e3)
hist(counts[, 2], main="CT.PA.2", xlim=c(0, 5000), breaks=1e3)
hist(counts[, 5], main="CT.PA.5", xlim=c(0, 5000), breaks=1e3)
hist(counts[, 7], main="CT.PA.7", xlim=c(0, 5000), breaks=1e3)
hist(counts[, 3], main="KD.SI.3", xlim=c(0, 5000), breaks=1e3)
hist(counts[, 4], main="KD.SI.4", xlim=c(0, 5000), breaks=1e3)
hist(counts[, 6], main="KD.SI.6", xlim=c(0, 5000), breaks=1e3)

# criar um objeto do tipo DGEList

d <- DGEList(counts=counts, group=samples$condition)

# estimar os fatores de normalizacao

d <- calcNormFactors(d)
d$samples

# dendrograma

dist <- as.dist(1 - cor(counts))
plot(hclust(dist))

# inspecionar as relacoes entre as amostras utilizando um grafico mds

plotMDS(d, labels=samples$shortname, col=c("darkgreen","blue")[factor(samples$condition)])

# estimar a dispersao por tags

d <- estimateCommonDisp(d)
d <- estimateTagwiseDisp(d)

# criar uma representacao visual da relacao entre a media e a variancia

plotMeanVar(d, show.tagwise.vars=TRUE, NBline=TRUE)
plotBCV(d)

# teste para a expressao diferencial dos genes

de <- exactTest(d, pair=c("CTL", "KD"))

# criar as estatisticas de diferenciacao

tt <- topTags(de, n=nrow(d))
head(tt$table)

# inspecionar as leituras ajustadas por tamanho de biblioteca para os genes com maior diferenciacao

nc <- cpm(d, normalized.lib.sizes=TRUE)
rn <- rownames(tt$table)
head(nc[rn, order(samples$condition)], 5)

# criar um resumo grafico, como o plot MA, mas utilizando os genes com diferencas significativas

deg <- rn[tt$table$FDR < 0.05]
plotSmear(d, de.tags=deg)

# fazer o histograma dos p-valores sem ajustes para verificar se os resultados estao ok

hist(de$table$PValue, breaks=100)

